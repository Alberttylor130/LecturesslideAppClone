import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { useCourses } from '../context/CourseContext';

const AddCourseScreen = ({ route, navigation }) => {
  const { courseId } = route.params || {};
  const { courses, addCourse, updateCourse } = useCourses();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (courseId) {
      const course = courses.find(course => course.id === courseId);
      if (course) {
        setTitle(course.title);
        setDescription(course.description);
      }
    }
  }, [courseId, courses]);

  const handleSaveCourse = () => {
    if (courseId) {
      // Editing an existing course
      updateCourse({
        id: courseId,
        title,
        description,
      });
    } else {
      // Adding a new course
      addCourse({
        id: new Date().getTime().toString(), // Unique ID for simplicity
        title,
        description,
      });
    }
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{courseId ? 'Edit Course' : 'Add New Course'}</Text>
      <TextInput
        placeholder="Course Title"
        value={title}
        onChangeText={setTitle}
        style={styles.input}
      />
      <TextInput
        placeholder="Course Description"
        value={description}
        onChangeText={setDescription}
        style={styles.input}
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveCourse}>
        <Text style={styles.buttonText}>{courseId ? 'Save Changes' : 'Add Course'}</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: '#007BFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default AddCourseScreen;
