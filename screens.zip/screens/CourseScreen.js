import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { useCourses } from '../context/CourseContext';

const CourseScreen = ({ route, navigation }) => {
  const { courseId } = route.params;
  const { courses } = useCourses();
  const course = courses.find(course => course.id === courseId);

  if (!course) {
    return (
      <View style={styles.container}>
        <Text>Course not found</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>{course.title}</Text>
      <Text>{course.description}</Text>
      <Button
        title="Edit Course"
        onPress={() => navigation.navigate('EditCourseScreen', { courseId })}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
  },
});

export default CourseScreen;
