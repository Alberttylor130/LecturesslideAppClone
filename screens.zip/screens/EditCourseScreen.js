import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { useCourses } from '../context/CourseContext';

const EditCourseScreen = ({ route, navigation }) => {
  const { courseId } = route.params;
  const { courses, updateCourse } = useCourses(); // Assuming updateCourse is a function in CourseContext
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    const course = courses.find(course => course.id === courseId);
    if (course) {
      setTitle(course.title);
      setDescription(course.description);
    }
  }, [courseId, courses]);

  const handleEditCourse = () => {
    const updatedCourse = {
      id: courseId,
      title,
      description,
    };
    updateCourse(updatedCourse); // Call the update function from context
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Edit Course</Text>
      <TextInput
        placeholder="Course Title"
        value={title}
        onChangeText={setTitle}
        style={styles.input}
      />
      <TextInput
        placeholder="Course Description"
        value={description}
        onChangeText={setDescription}
        style={styles.input}
      />
      <TouchableOpacity style={styles.button} onPress={handleEditCourse}>
        <Text style={styles.buttonText}>Save Changes</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: '#007BFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default EditCourseScreen;
