import React from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';
import { useCourses } from '../context/CourseContext';

const HomeScreen = ({ navigation }) => {
  const { courses } = useCourses();

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Welcome to Lecturesslide</Text>
      <FlatList
        data={courses}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.courseItem}>
            <Text style={styles.courseTitle}>{item.title}</Text>
            <Button
              title="View Course"
              onPress={() => navigation.navigate('CourseScreen', { courseId: item.id })}
            />
          </View>
        )}
      />
      <Button title="Add Course" onPress={() => navigation.navigate('AddCourseScreen')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
  },
  courseItem: {
    marginBottom: 10,
  },
  courseTitle: {
    fontSize: 18,
  },
});

export default HomeScreen;
