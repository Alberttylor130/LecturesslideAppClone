import React from 'react';
import { View, Text, Button, ImageBackground, StyleSheet } from 'react-native';

const WelcomeScreen = ({ navigation }) => {
  return (
    <ImageBackground
      source={require('../assets/g.jpg')} // Replace with your background image path
      style={styles.background}
    >
      <Text style={styles.text}>Welcome to LecturesslideAppClone2!</Text>
      <Button title="Get Started" onPress={() => navigation.navigate('SignupScreen')} />
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 24,
    color: 'white',
    marginBottom: 20,
  },
});

export default WelcomeScreen;
